<?php // $Id$ ?>
<div class="box">
  <?php if ($title): ?>
  <span class="title"><?php print $title; ?></span>
  <?php endif; ?>
  <?php print $content; ?>
</div>